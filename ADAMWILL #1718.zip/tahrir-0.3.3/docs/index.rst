Tahrir Documentation
====================

**This documentation is under construction.** In the meantime, you can
check out the
`readme <https://raw.github.com/fedora-infra/tahrir/develop/README.rst>`_,
which this starting documentation is being based on.

Tahrir is `Arabic for Liberation
<http://en.wikipedia.org/wiki/Tahrir_Square>`_.

Tahrir is also a `Pyramid <http://www.pylonsproject.org/>`_ app for issuing
your own `Open Badges <https://wiki.mozilla.org/Badges>`_.

The name is total overkill.

You can see Tahrir deployed in production `here
<https://badges.fedoraproject.org/>`_. The staging instance lives `here
<https://badges.stg.fedoraproject.org/>`_.

Contents:

.. toctree::
   :maxdepth: 2

   installation

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
