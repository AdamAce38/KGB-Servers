<?php
class myCustomMail extends ezcMail {}

class myFaultyCustomMail {}
?>
