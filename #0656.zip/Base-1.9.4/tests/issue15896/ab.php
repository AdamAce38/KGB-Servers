<?php

class ab
{
}

?>
