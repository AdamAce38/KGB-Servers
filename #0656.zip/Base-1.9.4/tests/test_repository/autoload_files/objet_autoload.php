<?php
return array(
	'Objet' => 'object/object.php',
);
?>
